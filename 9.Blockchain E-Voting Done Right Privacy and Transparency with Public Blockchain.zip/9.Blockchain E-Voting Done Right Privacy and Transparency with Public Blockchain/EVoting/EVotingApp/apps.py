from django.apps import AppConfig


class EvotingappConfig(AppConfig):
    name = 'EVotingApp'
